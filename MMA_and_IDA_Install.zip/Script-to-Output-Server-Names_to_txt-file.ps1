﻿<#
This script gathers a list of servers joined to the local default domain and outputs them to a file
Ver 1.0 2020-02-07
Written by Randy Dover, Airnet Group, Inc. support@airnetgroup.com
Script may be modified, by credit may not be removed

.NOTATIONS 
A list of the servers will be produced and saved in C:\Installs\AzureAgents, with the name of "ComputerNames.txt"
    Each server will be on its own line with no comma or other punctuation

#>

$strCategory = "computer" 
$strOperatingSystem = "Windows*Server*" 
 
$objDomain = New-Object System.DirectoryServices.DirectoryEntry 
 
$objSearcher = New-Object System.DirectoryServices.DirectorySearcher 
$objSearcher.SearchRoot = $objDomain 
 
$objSearcher.Filter = ("OperatingSystem=$strOperatingSystem") 
 
$colProplist = "name" 
foreach ($i in $colPropList){$objSearcher.PropertiesToLoad.Add($i)} 
 
$colResults = $objSearcher.FindAll() 
 
foreach ($objResult in $colResults) 
    { 
    $objComputer = $objResult.Properties;  
    $objComputer.name | out-File C:\Installs\AzureAgents\ComputerNames.txt -append
    }
