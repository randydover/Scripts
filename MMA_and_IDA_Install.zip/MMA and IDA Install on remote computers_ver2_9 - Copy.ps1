﻿<#
This script installs Microsoft Management Agent and InstallDependencyAgent-Windows.exe to remote computers
Ver 2.9 2020-03-23 Added notice to use Domain Creds when prompted
Ver 2.8 2020-03-20 Added code and note regarding Execution Policy Change
Ver 2.7 2020-03-20 Changed the placement of the Send-File.ps1 call placement
Ver 2.6 2020-03-20 Added "sleep" command to wait while the agents installed
Ver 2.5 2020-03-20 Re-ordered variables and prettied up the Instructions that appear on screen
Ver 2.4 2020-03-20 Added code to create the C:\Installs\AzureAgents folder and to create the necessary files
Ver 2.3 2020-03-20 Changed Computers.txt to ComputerNames.txt
Ver 2.2 2019-12-31

Written by Randy Dover, Airnet Group, Inc. support@airnetgroup.com
Script may be modified, by credit may not be removed

Some code borrowed from Niklas Akerlund 2015-10-13 https://vniklas.djungeln.se/2015/10/13/playing-with-automation-of-oms-agent-deployment/

.NOTATIONS 
Workspace ID must be retrieved from Azure Log Analytics and saved in C:\Installs\AzureAgents with name of "Workspace_ID.txt"
The Primary Key must be retrieved from Azure Log Analytics and saved in C:\Installs\AzureAgents with name of "Primary_Key.txt"
Optional: The Secondary Key must be retrieved from Azure Log Analytics and saved in C:\Installs\AzureAgents with name of "Secondary_Key.txt"
A list of servers the agents are to be installed on needs to be saved in C:\Installs\AzureAgents, with the name of "ComputerNames.txt"
    Each server must be on its own line with no comma or other punctuation
The file "Send-File.ps1" must be inluded in the C:\Installs\AzureAgents folder
    That file can be retrieved from: https://gallery.technet.microsoft.com/scriptcenter/Send-Files-or-Folders-over-273971bf
This script will download the required agent files on to the machine where this script is called
The script will install the Microsoft  Management Agent (MMA) and Install Dependency Agent (IDA) and connect them to the workspace in Azure

#>

Clear-Host
Write-Host " "
Write-Host "When prompted to allow Execution Policy Change, click Yes" -ForegroundColor Yellow
Write-Host "Execution Policy Change will allow this code to run" -ForegroundColor Yellow
Write-Host " "
[void](Read-Host 'Press Enter to continue…')
Clear-Host

Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

#The next line calls the Send-File Powershell script which will allow the files to be pushed to the target machines 
. C:\Installs\AzureAgents\Send-File.ps1

#This section sets the variables
$Computers = Get-Content -Path C:\Installs\AzureAgents\ComputerNames.txt 
$InstallsDir = "C:\Installs"
$AgentsDir = "C:\Installs\AzureAgents"
#$InstallFolder = "C:\Installs\AzureAgents"
$MMAFileName = "MMASetup-AMD64.exe"
$MMAFile32Name = "MMASetup-i386.exe"
$IDAFileName = "InstallDependencyAgent-Windows.exe"
$MMAFileAndPath = $AgentsDir + "\" + $MMAFileName
$MMAFile32AndPath = $AgentsDir + "\" + $MMAFile32Name
$IDAFileAndPath = $AgentsDir + "\" + $IDAFileName
$targetpath = "C:\Installs\AzureAgents"
$WorkSpaceID = Get-Content -Path C:\Installs\AzureAgents\Workspace_ID.txt
$WorkSpaceKey = Get-Content -Path C:\Installs\AzureAgents\Primary_Key.txt
$MMAinstallstring = $targetpath +'\MMASetup-AMD64.exe /C:"setup.exe /qn ADD_OPINSIGHTS_WORKSPACE=1 '+  "OPINSIGHTS_WORKSPACE_ID=$workspaceID " + "OPINSIGHTS_WORKSPACE_KEY=$workspaceKey " +'AcceptEndUserLicenseAgreement=1"'
$IDAinstallstring = $targetpath +'\InstallDependencyAgent-Windows.exe /S /AcceptEndUserLicenseAgreement:1'
$WorkspaceID =  "Workspace_ID.txt"
$PrimaryKey = "Primary_Key.txt"
$SecondaryKey = "Secondary_Key.txt"
#$SendFile = "C:\Installs\AzureAgents\Send-File.ps1"

#This section creates the C:\Installs folder, if it does not exist
if (-not (Test-Path -LiteralPath $InstallsDir)) {
    
    try {
        New-Item -Path $InstallsDir -ItemType Directory -ErrorAction Stop | Out-Null #-Force
    }
    catch {
        Write-Error -Message "Unable to create directory '$InstallsDir'. Error was: $_" -ErrorAction Stop
    }
    "Successfully created directory '$InstallsDir'."

}
else {
    "Directory already existed"
}

#This section creates the C:\Installs\AzureAgents folder, if it does not exist
if (-not (Test-Path -LiteralPath $AgentsDir)) {
    
    try {
        New-Item -Path $AgentsDir -ItemType Directory -ErrorAction Stop | Out-Null #-Force
    }
    catch {
        Write-Error -Message "Unable to create directory '$AgentsDir'. Error was: $_" -ErrorAction Stop
    }
    "Successfully created directory '$AgentsDir'."

}
else {
    "Directory already existed"
}

#This section creates the WorkspaceID file if it doesn't exist
if (!(Test-Path $AgentsDir+"\"+$WorkspaceID))
{
New-Item -itemType File -Path $AgentsDir -Name $WorkspaceID
}
else
{
Write-Host "File already exists"
}

#This section creates the Primary_Key file if it doesn't exist
if (!(Test-Path $AgentsDir+"\"+$PrimaryKey))
{
New-Item -itemType File -Path $AgentsDir -Name $PrimaryKey
}
else
{
Write-Host "File already exists"
}

#This section creates the Secondary_Key file if it doesn't exist
if (!(Test-Path $AgentsDir+"\"+$SecondaryKey))
{
New-Item -itemType File -Path $AgentsDir -Name $SecondaryKey
}
else
{
Write-Host "File already exists"
}

#This section gives instruction to copy the required files to the Installation folder
Clear-Host
Write-Host " "
Write-Host "Before proceeding, connect to Azure LogAnalytics > Advanced Settings" -ForegroundColor Yellow
Write-Host "Save the Workspace ID to the file named Workspace_ID.txt in the C:\Installs\AzureAgents folder" -ForegroundColor Yellow
Write-Host "Save the Primary Key to the file named Primary_Key.txt in the C:\Installs\AzureAgents folder" -ForegroundColor Yellow
Write-Host "Save the Secondary Key to the file named Secondary_Key.txt in the C:\Installs\AzureAgents folder" -ForegroundColor Yellow
Write-Host "     The Secondary Key is optional" -ForegroundColor Yellow
Write-Host "Place the Send-File.ps1 file into the C:\Installs\AzureAgents folder" -ForegroundColor Yellow
Write-Host "Save the list of computers to be installed on in a file named ComputerNames.txt into the C:\Installs\AzureAgents folder" -ForegroundColor Yellow
Write-Host " "
[void](Read-Host 'Press Enter to continue…')
Clear-Host

#Instruction to enter Domain Admin level section
Clear-Host
Write-Host "" -ForegroundColor Yellow
Write-Host "You are about to be prompted for Username and Password, enter Domain Admin level credentials" -ForegroundColor Yellow
Write-Host ""

[void](Read-Host 'Press Enter to continue…')
Clear-Host
$cred = Get-Credential 


#This section downloads the required agents
# Download OMS Log Analytics monitoring agent
Write-Verbose "downloading monitoring agent..."
$URL = "https://go.microsoft.com/fwlink/?LinkId=828603"
Invoke-WebRequest -Uri $URl -OutFile $MMAFileAndPath | Out-Null
Write-Verbose "Downloaded!"

# Download OMS Log Analytics 32-bit monitoring agent
Write-Verbose "downloading 32-bit monitoring agent..."
$URL = "https://go.microsoft.com/fwlink/?LinkId=828604"
Invoke-WebRequest -Uri $URl -OutFile $MMAFile32AndPath | Out-Null
Write-Verbose "Downloaded!"

# Download OMS Log Analytics dependency agent
Write-Verbose "downloading dependency agent..."
$URL = "https://aka.ms/dependencyagentwindows"
Invoke-WebRequest -Uri $URl -OutFile $IDAFileAndPath | Out-Null
Write-Verbose "Downloaded!"

#This section does the actual install of the agents 
foreach ($computer in $computers){
    $pssessionMMA = New-PSSession -ComputerName $computer -Credential $cred
  
    Send-File -Path $MMAFileAndPath -Destination $targetpath -Session $pssessionMMA
 
    Invoke-Command -Session $pssessionMMA -ScriptBlock {
 
        CMD.exe /C $using:MMAinstallstring
        {
        Write-Host "Waiting for Monitoring Agent install to complete"
        }
        Start-Sleep -S 30
    }
    Remove-PSSession -Session $pssessionMMA
 
   $pssessionIDA = New-PSSession -ComputerName $computer -Credential $cred

   Send-File -Path $IDAFileAndPath -Destination $targetpath -Session $pssessionIDA

 Invoke-Command -Session $pssessionIDA -ScriptBlock {
 
        CMD.exe /C $using:IDAinstallstring
        {
        Write-Host "Waiting for Dependency Agent install to complete"
        }
        Start-Sleep -S 30
    }
    Remove-PSSession -Session $pssessionIDA
}

Write-Host " "
Write-Host "Agents have been installed" -ForegroundColor Yellow
Write-Host "Please scroll up and create screen shots of all the computers that were processed via the script" -ForegroundColor Yellow
Write-Host " "
[void](Read-Host 'Press Enter to continue…')