<#
This script downloads Microsoft ASR Unified Setup 9.33
Ver 1.0 2020-06-06 First iteration of downloading MicrosoftAzureSiteRecoveryUnifiedSetup.exe

Written by Randy Dover, Airnet Group, Inc. support@airnetgroup.com
Script may be modified, by credit may not be removed


.NOTATIONS 
https://support.microsoft.com/en-us/help/4564347/update-rollup-46-for-azure-site-recovery
#>

#Variable section
$InstallsFolder = "C:\Installs"
$ASRUnifiedFolder = "C:\Installs\MicrosoftASRUnifiedSetup"
$WinMgmtFrameworkFile = "MicrosoftAzureSiteRecoveryUnifiedSetup.exe"
$PathAndFile = $ASRUnifiedFolder + "\" + $WinMgmtFrameworkFile

#This section creates the C:\Installs folder, if it does not exist
if (-not (Test-Path -LiteralPath $InstallsFolder)) {
    
    try {
        New-Item -Path $InstallsFolder -ItemType Directory -ErrorAction Stop | Out-Null #-Force
    }
    catch {
        Write-Error -Message "Unable to create directory '$InstallsFolder'. Error was: $_" -ErrorAction Stop
    }
    "Successfully created directory '$InstallsFolder'."

}
else {
    "Directory already existed"
}

#This section creates the C:\Installs\MicrosoftASRUnifiedSetup folder, if it does not exist
if (-not (Test-Path -LiteralPath $ASRUnifiedFolder)) {
    
    try {
        New-Item -Path $ASRUnifiedFolder -ItemType Directory -ErrorAction Stop | Out-Null #-Force
    }
    catch {
        Write-Error -Message "Unable to create directory '$ASRUnifiedFolder'. Error was: $_" -ErrorAction Stop
    }
    "Successfully created directory '$ASRUnifiedFolder'."

}
else {
    "Directory already existed"
}

# Download Microsoft ASR Unified Setup
Write-Verbose "downloading Microsoft ASR Unified Setup 9.33..."
$URL = "https://download.microsoft.com/download/8/b/3/8b3e3d5e-4c4c-410e-b1b5-d1d2f984f0c9/MicrosoftAzureSiteRecoveryUnifiedSetup.exe"
Invoke-WebRequest -Uri $URl -OutFile $PathAndFile | Out-Null
Write-Verbose "Downloaded!"

Unblock-File $PathAndFile