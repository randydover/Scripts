<#
This script installs the VMAccessAgent after a computer has been migrated to Azure
Ver 1.3 20200603 Changed $NetFileAndPath to $NetPathAndFile
Ver 1.2 20200520 Added code to set TLS level
Ver 1.1 20200520 Add section to Install AZVM module
Ver 1.0 20200520 First iteration

Written by Randy Dover, Airnet Group, Inc. support@airnetgroup.com
Script may be modified, by credit may not be removed

.NOTATIONS 
https://docs.microsoft.com/en-us/azure/virtual-machines/extensions/agent-windows#manual-installation
#>

Clear-Host
Write-Host " "
Write-Host "Before proceeding, Make sure you have run PowerShell as Administrator. If not, exit now and launch as Administrator" -ForegroundColor Yellow
Write-Host ""
[void](Read-Host 'Press Enter to continue�')
Clear-Host

#Variable section
$PathName = "C:\Installs\VMAccessAgent"
$FileName = (Get-Childitem $PathName\windowsAzureVMAgen*.msi)

#Install section
Start-Process msiexec.exe -Wait -ArgumentList '/I $PathName\$FileName /quiet'

#Check .Net Version equal to or greater than 4.7.2
$NetVersion = (Get-ItemProperty "HKLM:SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full").Release
$NetCheck = 461808 # The .Net target version put in a variable so we can Write-Host it in strings 

# If the .Net version is less than 461808
if ($NetVersion -lt $NetCheck) {
    Write-Host ".Net Version: $NetVersion < $NetCheck"

    # Download .Net 4.8.0
    $InstallsDir = "C:\Installs"
    $NetDir = "C:\Installs\VMAccessAgent"
    $NetFile = "ndp48-x86-x64-allos-enu.exe"
    $NetPathAndFile = $NetDir + "\" + $NetFile

    #This section creates the C:\Installs folder, if it does not exist
    if (-not (Test-Path -LiteralPath $InstallsDir)) {
        try {
            New-Item -Path $InstallsDir -ItemType Directory -ErrorAction Stop | Out-Null #-Force
        } catch {
            Write-Error -Message "Unable to create directory '$InstallsDir'. Error was: $_" -ErrorAction Stop
        }

        Write-Host "Successfully created directory '$InstallsDir'."

    } else {
        Write-Host "Directory '$InstallsDir' already exists"
    }

    #This section creates the C:\Installs\AzureAgents folder, if it does not exist
    if (-not (Test-Path -LiteralPath $NetDir)) {
        try {
            New-Item -Path $NetDir -ItemType Directory -ErrorAction Stop | Out-Null #-Force
        } catch {
            Write-Error -Message "Unable to create directory '$NetDir'. Error was: $_" -ErrorAction Stop
        }

        Write-Host "Successfully created directory '$NetDir'."

    } else {
        Write-Host "Directory '$NetDir' already exists"
    }

    # See if the file has been downloaded or not
    if (-not (Test-Path -LiteralPath $NetDir)) {
        Write-Verbose "downloading VMAccessAgent..."
        $URL = "https://go.microsoft.com/fwlink/?linkid=2088631"
        Invoke-WebRequest -Uri $URl -OutFile $NetPathAndFile | Out-Null
        Write-Host "Downloaded!"

        Unblock-File $NetPathAndFile
    } else {
        Write-Host "File '$NetPathAndFile' already exists"
    }

    Write-Host "Installing '$NetPathAndFile' ..."
    #Invoke-Command $NetPathAndFile
    Write-Host "Done!"

} else {
    Write-Host ".Net version ($NetVersion) >= $NetCheck already installed"
}

#Sets TLS to required level
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

#Install AZ-VM module
Install-Module az

#Update Azure section
$vm.OSProfile.AllowExtensionOperations = $true
$vm | Update-AzVM