<#
This script installs the VMAccessAgent after a computer has been migrated to Azure
Ver 1.4 20200603 Original script included downloading PowerShell update and install of AZ-Module, removed those, so this version just installs the VM Agent.
Ver 1.3 20200603 Changed $NetFileAndPath to $NetPathAndFile
Ver 1.2 20200520 Added code to set TLS level
Ver 1.1 20200520 Add section to Install AZVM module
Ver 1.0 20200520 First iteration

Written by Randy Dover, Airnet Group, Inc. support@airnetgroup.com
Script may be modified, by credit may not be removed

.NOTATIONS 
https://docs.microsoft.com/en-us/azure/virtual-machines/extensions/agent-windows#manual-installation
#>

Clear-Host
Write-Host " "
Write-Host "Before proceeding, Make sure you have run PowerShell as Administrator. If not, exit now and launch as Administrator" -ForegroundColor Yellow
Write-Host ""
[void](Read-Host 'Press Enter to continue�')
Clear-Host

#Variable section
$PathName = "C:\Installs\VMAccessAgent"
$FileName = (Get-Childitem $PathName\windowsAzureVMAgen*.msi)

#Install section
Start-Process msiexec.exe -Wait -ArgumentList '/I $PathName\$FileName /quiet'
