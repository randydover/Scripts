<#
This script will set the TLS level of PowerShell equal to TLS1.2
Ver 1.0 2020-05-21 Initial attempt

Written by Randy Dover, Airnet Group, Inc. support@airnetgroup.com
Script may be modified, by credit may not be removed

.NOTATIONS
If you attempt to install the AZ module and it doesn't install, first check to make sure you have .net 4.7.2 or higher
If you get errors:
WARNING: Unable to download from URI 'https://go.microsoft.com/fwlink/?LinkID=627338&clcid=0x409' to ''.
WARNING: Unable to download the list of available providers. Check your internet connection.
You probably need to enable TLS 1.2 for Powershell
Link: https://answers.microsoft.com/en-us/windows/forum/windows_7-performance/trying-to-install-program-using-powershell-and/4c3ac2b2-ebd4-4b2a-a673-e283827da143
#>

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12