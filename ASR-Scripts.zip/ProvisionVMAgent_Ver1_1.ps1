﻿<#
This script will reset a local admin password on an Azure VM
Ver 1.0 2020-05-21 Added call of multiple computers
Ver 1.0 2020-05-20 Initial attempt

Written by Randy Dover, Airnet Group, Inc. support@airnetgroup.com
Script may be modified, by credit may not be removed

.NOTATIONS 
A list of computers the agent will need to be installed on needs to be saved in the same folder the script is located in
The file name of "ComputerNames.txt"
    Each server must be on its own line with no comma or other punctuation
#>
#You must sign in with an Azure account
Connect-AzAccount

#This section creates a variable to use the current path as the execution path
$MyDir = Split-Path $script:MyInvocation.MyCommand.Path
$Computers = Get-Content -Path $MyDir\ComputerNames.txt
$ResourceGroup = "rg_testmigration_preprod_eastus"

Clear-Host
Write-Host " "
Write-Host "Before proceeding, You should have installed the VMAccessAgent on the target Machines" -ForegroundColor Yellow
Write-Host ""

[void](Read-Host 'Press Enter to continue…')

#This section does the work of provisioning the agent
Foreach ($Computer in $Computers)
{
$VM = Get-AzVM -ResourceGroupName $ResourceGroup -Name $Computer
$vm.OSProfile.WindowsConfiguration.ProvisionVMAgent
$vm.OSProfile.AllowExtensionOperations


$vm.OSProfile.AllowExtensionOperations = $true
$vm | Update-AzVM
}