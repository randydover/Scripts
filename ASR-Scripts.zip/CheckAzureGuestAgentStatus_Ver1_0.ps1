﻿<#
This script will check the Azure Guest Agent status of Azure VMs
Ver 1.0 2020-05-20 Initial attempt

Written by Randy Dover, Airnet Group, Inc. support@airnetgroup.com
Script may be modified, by credit may not be removed

.NOTATIONS 
Code supplied by a Microsoft tech, code on Web site is wrong.
#>
$vm_list = Get-AZVM #You can add a filter here to get a smaller list.
foreach ($vm in $vm_list)
{
$vm_status = Get-AZVM -Name $Vm.Name -ResourceGroupName $Vm.ResourceGroupName -Status
$guest_agent_status = $vm_status.VMAgent.Statuses
Write-Output $vm.Name $guest_agent_status.DisplayStatus
}
