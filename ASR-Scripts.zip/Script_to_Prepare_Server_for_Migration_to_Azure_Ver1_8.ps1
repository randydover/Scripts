﻿<#
This script prepares a computer to be migrated to Azure
Ver 1.8 20200519 Added section to download VMAccess agent instead of having to run separate script
Ver 1.7 20200519 Added a pause before DiskPart is called so wording of what to copy can be seen 
Ver 1.6 20200519 Added notice the script must be run as administrator
Ver 1.5 20200519 Added [void](Read-Host 'Press Enter to continue…') to pause for DiskPart
Ver 1.4 20200519 Added "q" section to check for presence of vmstorfl.sys (for Server 2008)
Ver 1.3 20200519 Added "p" section to turn off "Shutdown Event Tracker"
Ver 1.2 20200519 Added "o" section to turn off NIC PowerManagement
Ver 1.1 20200518 Added "d" section to run diskpart inside of PowerShell script
Ver 1.0 20200518 Sets specific settings to what is required for a successful migration and communication after migration

Written by Randy Dover, Airnet Group, Inc. support@airnetgroup.com
Script may be modified, by credit may not be removed

.NOTATIONS 
Settings referenced in:
https://docs.microsoft.com/en-us/azure/migrate/prepare-for-migration
https://docs.microsoft.com/en-us/azure/virtual-machines/windows/prepare-for-upload-vhd-image#check-the-windows-services
https://docs.microsoft.com/en-us/azure/virtual-machines/troubleshooting/serial-console-windows

#>

Clear-Host
Write-Host " "
Write-Host "Before proceeding, Make sure you have run PowerShell as Administrator. If not, exit now and launch as Administrator" -ForegroundColor Yellow
Write-Host ""
[void](Read-Host 'Press Enter to continue…')
Clear-Host

#a: Remove the WinHTTP proxy
netsh.exe winhttp reset proxy

#b:  Check the Windows services - Automatic
Get-Service -Name BFE, Dhcp, Dnscache, IKEEXT, iphlpsvc, nsi, mpssvc, RemoteRegistry |
    Where-Object StartType -ne Automatic |
        Set-Service -StartupType Automatic

#c: Check the Windows services - Manual
Get-Service -Name Netlogon, Netman, TermService |
    Where-Object StartType -ne Manual |
    Set-Service -StartupType Manual

#d: DiskPart to preserve all drive letters "diskpart.exe"
Clear-Host
Write-Host " "
Write-Host "Diskpart is about to be called" -ForegroundColor Yellow
Write-Host "Copy the next line and paste it into diskpart when it runs" -ForegroundColor Yellow
Write-Host "san policy=onlineall" -ForegroundColor Yellow
Write-Host "Type exit and press the Enter key to exit DiskPart" -ForegroundColor Yellow
Write-Host ""
[void](Read-Host 'Press Enter to continue…')
Start-Process diskpart
#		DISKPART> san policy=onlineall
#		DISKPART> exit
Clear-Host
Write-Host " "
[void](Read-Host 'Press Enter to continue…')

#e: Set Power Profile to High
powercfg.exe /setactive SCHEME_MIN

#f: Set TEMP and TMP variables
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Environment' -Name TEMP -Value "%SystemRoot%\TEMP" -Type ExpandString -Force
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Environment' -Name TMP -Value "%SystemRoot%\TEMP" -Type ExpandString -Force

#g: Set RDP to enable
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server' -Name fDenyTSConnections -Value 0 -Type DWord -Force
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' -Name fDenyTSConnections -Value 0 -Type DWord -Force

#h: Set RDP port to 3389
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\Winstations\RDP-Tcp' -Name PortNumber -Value 3389 -Type DWord -Force

#i: Set RDP listener:
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\Winstations\RDP-Tcp' -Name LanAdapter -Value 0 -Type DWord -Force

#j: Turn off firewall
Set-NetFirewallProfile -Profile Domain, Private -Enabled False

#k: Enable PSRemoting
Enable-PSRemoting -Force
Set-NetFirewallRule -DisplayName 'Windows Remote Management (HTTP-In)' -Enabled True

#l: Enable Firewall Rules for RDP:
Set-NetFirewallRule -DisplayGroup 'Remote Desktop' -Enabled True

#m: Enable File and Print Sharing connectiong
Set-NetFirewallRule -DisplayName 'File and Printer Sharing (Echo Request - ICMPv4-In)' -Enabled True

#n: Enable Azure Serial Console 
bcdedit /ems '{current}' on
bcdedit /emssettings EMSPORT:1 EMSBAUDRATE:115200

#o: Turns off Power Management for all Physical NICs
$adapters = Get-NetAdapter -Physical | Get-NetAdapterPowerManagement
    foreach ($adapter in $adapters)
        {
        $adapter.AllowComputerToTurnOffDevice = 'Disabled'
        $adapter | Set-NetAdapterPowerManagement
        }

#p: Disables "Shutdown Event Tracker"
if ( -Not (Test-Path 'registry::HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Reliability'))
{
New-Item -Path 'registry::HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT' -Name Reliability -Force
}
Set-ItemProperty -Path 'registry::HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Reliability' -Name ShutdownReasonOn -Value 0

#q: This section checks if OS is 2008 Server
    # If Server 2008, checks if vmstorfl.sys file exists, and if not creates it. This file is required post migration
$OSVersion = (Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -Name ProductName).ProductName
If ($OSVersion.contains("2008")) 
    {
    if ((Test-Path "C:\Windows\system32\drivers\vmstorfl.sys")) 
    {
        Write-Host "File already exists"
    } 
    else 
        {
        New-Item -path C:\Windows\system32\drivers\ -name vmstorfl.sys -type "file"
        Write-Host "Created new vmstorfl.sys file"
        }
    } 
    else 
    {
      Write-Host "OS Version not 2008"
    }

#r: Downloads VMAccess Agent
#Variable section
$InstallsDir = "C:\Installs"
$VMAgentDir = "C:\Installs\VMAccessAgent"
$VMAccessFile = "WindowsAzureVmAgent.2.7.41491.949_191001-1418.fre.msi"
$FileAndPath = $VMAgentDir + "\" + $VMAccessFile
sleep 10

#This section creates the C:\Installs folder, if it does not exist
if (-not (Test-Path -LiteralPath $InstallsDir)) {
    
    try {
        New-Item -Path $InstallsDir -ItemType Directory -ErrorAction Stop | Out-Null #-Force
    }
    catch {
        Write-Error -Message "Unable to create directory '$InstallsDir'. Error was: $_" -ErrorAction Stop
    }
    "Successfully created directory '$InstallsDir'."

}
else {
    "Directory already existed"
}

#This section creates the C:\Installs\AzureAgents folder, if it does not exist
if (-not (Test-Path -LiteralPath $VMAgentDir)) {
    
    try {
        New-Item -Path $VMAgentDir -ItemType Directory -ErrorAction Stop | Out-Null #-Force
    }
    catch {
        Write-Error -Message "Unable to create directory '$VMAgentDir'. Error was: $_" -ErrorAction Stop
    }
    "Successfully created directory '$VMAgentDir'."

}
else {
    "Directory already existed"
}

# Download VMAccessAgent
Write-Verbose "downloading VMAccessAgent..."
$URL = "https://go.microsoft.com/fwlink/?LinkID=394789"
Invoke-WebRequest -Uri $URl -OutFile $FileAndPath | Out-Null
Write-Verbose "Downloaded!"

Unblock-File $FileAndPath

Write-Host "Script Process complete"